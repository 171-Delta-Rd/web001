/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80013
 Source Host           : localhost:3306
 Source Schema         : xm_ticket_manager

 Target Server Type    : MySQL
 Target Server Version : 80013
 File Encoding         : 65001

 Date: 03/06/2024 11:03:20
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '姓名',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '头像',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色标识',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '电话',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '管理员' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'admin', '123456', '管理员', 'http://localhost:9090/files/1697438073596-avatar.png', 'ADMIN', '13677889922', 'admin@xm.com');

-- ----------------------------
-- Table structure for airorders
-- ----------------------------
DROP TABLE IF EXISTS `airorders`;
CREATE TABLE `airorders`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '航班名称',
  `user_id` int(10) NULL DEFAULT NULL COMMENT '用户ID',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '下单时间',
  `fly_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '起飞时间',
  `start_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '起始机场',
  `end_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达机场',
  `time_slot` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '航班时长',
  `num` int(10) NULL DEFAULT NULL COMMENT '机票数量',
  `price` double(10, 2) NULL DEFAULT NULL COMMENT '机票价格',
  `order_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '订单编号',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '订单状态',
  `ticket_id` int(10) NULL DEFAULT NULL COMMENT '机票ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '飞机票订单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of airorders
-- ----------------------------
INSERT INTO `airorders` VALUES (9, '南方航空 CZ2809空客321（大）', 1, '2024-05-09 17:22:15', '2024-05-10 16:00:00', '上海国际机场', '合肥新桥机场', '2小时', 2, 1200.00, '20240509172215', '已退票', 6);
INSERT INTO `airorders` VALUES (10, '南方航空 CZ2809空客321（大）', 1, '2024-05-09 17:28:54', '2024-05-08 16:00:00', '上海国际机场', '合肥新桥机场', '2小时', 1, 1200.00, '20240509172854', '已购买', 6);
INSERT INTO `airorders` VALUES (11, '南方航空 CZ2809空客321（大）', 1, '2024-05-28 10:10:17', '2024-05-29 16:00:00', '上海国际机场', '合肥新桥机场', '2小时', 1, 1200.00, '20240528101017', '已购买', 6);
INSERT INTO `airorders` VALUES (12, '上海航空 FM9096空客320（中）', 1, '2024-05-28 10:57:14', '2024-05-30 13:00:00', '上海国际机场', '合肥新桥机场', '2小时', 1, 1000.00, '20240528105714', '已购买', 5);
INSERT INTO `airorders` VALUES (13, '山东航空 SC7660波音777（大）', 1, '2024-05-31 16:39:18', '2024-06-01 10:00:00', '烟台国际机场', '上海国际机场', '3小时', 1, 1300.00, '20240531163918', '已购买', 2);

-- ----------------------------
-- Table structure for airticket
-- ----------------------------
DROP TABLE IF EXISTS `airticket`;
CREATE TABLE `airticket`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '航班名称',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '航班Logo',
  `start_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发时间',
  `end_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达时间',
  `start_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发机场',
  `end_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达机场',
  `price` double(10, 2) NULL DEFAULT NULL COMMENT '机票费用',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '航班时长',
  `num` int(10) NULL DEFAULT 0 COMMENT '剩余票数',
  `start_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发城市',
  `end_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达城市',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '飞机票信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of airticket
-- ----------------------------
INSERT INTO `airticket` VALUES (1, '四川航空 3U8198波音777（中）', 'http://localhost:9090/files/1715074855376-四川航空.png', '08:00:00', '10:20:00', '重庆国际机场', '上海国际机场', 1200.00, '2小时15分钟', 0, '重庆', '上海');
INSERT INTO `airticket` VALUES (2, '山东航空 SC7660波音777（大）', 'http://localhost:9090/files/1715152936697-山东航空.png', '10:00:00', '13:00:00', '烟台国际机场', '上海国际机场', 1300.00, '3小时', 99, '烟台', '上海');
INSERT INTO `airticket` VALUES (3, '东方航空 MU6639波音737（中）', 'http://localhost:9090/files/1715153014532-东方航空.png', '13:00:00', '15:00:00', '大连国际机场', '上海浦东机场', 1400.00, '2小时', 100, '大连', '上海');
INSERT INTO `airticket` VALUES (4, '吉祥航空 HO1196波音737（中）', 'http://localhost:9090/files/1715153079353-吉祥航空.png', '10:30:00', '13:00:00', '青岛国际机场', '上海国际机场', 1300.00, '2小时30分钟', 100, '青岛', '上海');
INSERT INTO `airticket` VALUES (5, '上海航空 FM9096空客320（中）', 'http://localhost:9090/files/1715153140786-上海航空.png', '13:00:00', '15:00:00', '上海国际机场', '合肥新桥机场', 1000.00, '2小时', 100, '上海', '合肥');
INSERT INTO `airticket` VALUES (6, '南方航空 CZ2809空客321（大）', 'http://localhost:9090/files/1715153191810-南方航空.png', '16:00:00', '18:30:00', '上海国际机场', '合肥新桥机场', 1200.00, '2小时', 97, '上海', '合肥');
INSERT INTO `airticket` VALUES (7, '厦门航空 MF4706空客320（中）', 'http://localhost:9090/files/1715153257361-厦门航空.png', '13:30:00', '16:00:00', '上海国际机场', '北京大兴国际机场', 1200.00, '2小时30分钟', 94, '上海', '北京');

-- ----------------------------
-- Table structure for busorders
-- ----------------------------
DROP TABLE IF EXISTS `busorders`;
CREATE TABLE `busorders`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '车次名称',
  `user_id` int(10) NULL DEFAULT NULL COMMENT '用户ID',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '下单时间',
  `fly_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发时间',
  `start_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发站',
  `end_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达站',
  `time_slot` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '车次时长',
  `num` int(10) NULL DEFAULT NULL COMMENT '车票数量',
  `price` double(10, 2) NULL DEFAULT NULL COMMENT '车票价格',
  `order_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '订单编号',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '订单状态',
  `ticket_id` int(10) NULL DEFAULT NULL COMMENT '车票ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 17 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '汽车票订单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of busorders
-- ----------------------------
INSERT INTO `busorders` VALUES (15, '沪杭专线', 1, '2024-05-29 16:52:59', '2024-05-30 13:30:00', '上海长途汽车客运总站', '杭州客运中心站', '约3小时', 1, 200.00, '20240529165259', '已退票', 21);
INSERT INTO `busorders` VALUES (16, '沪合专线', 1, '2024-05-29 16:55:21', '2024-05-30 13:00:00', '上海长途汽车客运总站', '合肥汽车客运总站', '约8小时', 1, 300.00, '20240529165521', '已购买', 19);
INSERT INTO `busorders` VALUES (17, '青沪专线', 1, '2024-05-31 16:42:19', '2024-06-01 10:30:00', '青岛汽车北站', '上海长途汽车客运总站', '约6小时', 1, 600.00, '20240531164219', '已购买', 18);

-- ----------------------------
-- Table structure for busticket
-- ----------------------------
DROP TABLE IF EXISTS `busticket`;
CREATE TABLE `busticket`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '车次名称',
  `start_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发时间',
  `end_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达时间',
  `start_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发站',
  `end_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达站',
  `price` double(10, 2) NULL DEFAULT NULL COMMENT '车票费用',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '车次时长',
  `num` int(10) NULL DEFAULT 0 COMMENT '剩余票数',
  `start_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发城市',
  `end_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达城市',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '汽车票信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of busticket
-- ----------------------------
INSERT INTO `busticket` VALUES (15, '重庆专线', '08:00:00', '10:20:00', '重庆客运总站', '上海长途汽车客运总站', 800.00, '约12小时', 100, '重庆', '上海');
INSERT INTO `busticket` VALUES (16, '烟沪专线', '10:00:00', '13:30:00', '烟台客运总站', '上海长途汽车客运总站', 300.00, '约5小时', 100, '烟台', '上海');
INSERT INTO `busticket` VALUES (17, '大连沪线', '13:00:00', '15:00:00', '大连客运总站', '上海长途汽车客运总站', 300.00, '约3小时', 100, '大连', '上海');
INSERT INTO `busticket` VALUES (18, '青沪专线', '10:30:00', '13:00:00', '青岛汽车北站', '上海长途汽车客运总站', 600.00, '约6小时', 99, '青岛', '上海');
INSERT INTO `busticket` VALUES (19, '沪合专线', '13:00:00', '15:00:00', '上海长途汽车客运总站', '合肥汽车客运总站', 300.00, '约8小时', 100, '上海', '合肥');
INSERT INTO `busticket` VALUES (20, '沪合专线', '16:00:00', '18:30:00', '上海浦东长途东站', '合肥汽车客运西站', 280.00, '约7小时', 99, '上海', '合肥');
INSERT INTO `busticket` VALUES (21, '沪杭专线', '13:30:00', '16:00:00', '上海长途汽车客运总站', '杭州客运中心站', 200.00, '约3小时', 100, '上海', '杭州');

-- ----------------------------
-- Table structure for collect
-- ----------------------------
DROP TABLE IF EXISTS `collect`;
CREATE TABLE `collect`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `introduction_id` int(10) NULL DEFAULT NULL COMMENT '攻略ID',
  `user_id` int(10) NULL DEFAULT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '攻略收藏表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of collect
-- ----------------------------
INSERT INTO `collect` VALUES (6, 7, 1);
INSERT INTO `collect` VALUES (7, 6, 1);
INSERT INTO `collect` VALUES (8, 5, 1);

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `user_id` int(10) NULL DEFAULT NULL COMMENT '用户ID',
  `introduction_id` int(10) NULL DEFAULT NULL COMMENT '攻略ID',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '评论内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '评论时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '攻略评论表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES (6, 1, 7, '这个地方真的美！！', '2024-06-03 10:48:26');
INSERT INTO `comment` VALUES (7, 1, 7, '6666', '2024-06-03 10:48:52');
INSERT INTO `comment` VALUES (8, 1, 7, '8888', '2024-06-03 10:51:10');
INSERT INTO `comment` VALUES (9, 1, 6, '哈哈哈哈哈', '2024-06-03 10:53:18');
INSERT INTO `comment` VALUES (10, 1, 7, '哈哈哈', '2024-06-03 10:55:40');
INSERT INTO `comment` VALUES (11, 1, 5, '9999', '2024-06-03 10:55:56');

-- ----------------------------
-- Table structure for introduction
-- ----------------------------
DROP TABLE IF EXISTS `introduction`;
CREATE TABLE `introduction`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT ' ',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '攻略标题',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '攻略主图',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '攻略详情',
  `comment` int(10) NULL DEFAULT 0 COMMENT '评论数',
  `collect` int(10) NULL DEFAULT 0 COMMENT '收藏数',
  `views` int(10) NULL DEFAULT 0 COMMENT '浏览量',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '发布时间',
  `user_id` int(10) NULL DEFAULT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '旅游攻略表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of introduction
-- ----------------------------
INSERT INTO `introduction` VALUES (3, '江苏省苏州市【田园绿洲】', 'http://localhost:9090/files/1716975922033-田园绿洲.jpg', '<p>详细介绍：</p><p>田园绿洲位于中国的江苏省苏州市吴江区，被誉为江南水乡的一颗明珠。这个农家乐以其独特的自然风光、丰富的农耕文化和宁静的乡村环境而闻名，吸引了大量的游客前来体验。</p><p>田园绿洲占地面积广阔，拥有大片的农田、果园、鱼塘和花园。这里的建筑风格以传统的江南水乡民居为主，粉墙黛瓦，古色古香。农家乐的庭院宽敞，布满了各种花草树木，给人一种宁静和舒适的感觉。</p><p>在田园绿洲，游客可以参观农田和果园，了解水稻、小麦、果树等农作物的种植技术，并亲自参与农耕活动，如插秧、收割、采摘等。此外，农家乐还提供了丰富的娱乐活动，如钓鱼、划船、骑行等，让游客在享受大自然的同时，也能感受到乡村生活的乐趣。</p><p>除了农业观光和娱乐活动，田园绿洲还为游客提供了地道的江南美食。这里的食材大部分来自于自家的农田和果园，新鲜、绿色、无污染。游客可以品尝到各种美味的农家菜，如清蒸鱼、红烧肉、时令蔬菜等。此外，农家乐还为游客提供了宽敞的餐厅和舒适的休息区，让游客在品尝美食的同时，也能享受到宁静的乡村氛围。</p><p><img src=\"http://101.35.218.50:9091/files/1702132059075-%E7%94%B0%E5%9B%AD%E7%BB%BF%E6%B4%B2.jpg\"/></p><p>三、联系方式：</p><p>电话：+86-512-63458766</p><p>邮箱：<a href=\"mailto:tianyuanozhou@example.com\" target=\"_blank\">tianyuanozhou@example.com</a></p><p>四、交通指南：</p><ol><li>飞机：从全国各地可以乘坐飞机到达上海虹桥国际机场或南京禄口国际机场，然后乘坐出租车或高铁到达苏州市区，再换乘公交车或出租车到达田园绿洲。</li><li>高铁/火车：从全国各地可以乘坐高铁或火车到达苏州站或苏州北站，然后换乘公交车或出租车到达田园绿洲。从苏州市区出发，乘坐公交车约需1小时左右的车程。</li><li>自驾：从苏州市区出发，沿着吴江大道向南行驶，经过约30分钟的车程即可到达田园绿洲。沿途风景秀丽，路况良好，适合自驾游。游客可以在农家乐内停车。</li></ol><p>五、特色活动：</p><ol><li>农耕体验：游客可以参与农耕活动，如插秧、收割、打谷等，亲身体验农耕的乐趣。农家乐提供了相关的工具和指导，确保游客能够安全地进行农耕活动。</li><li>钓鱼比赛：农家乐定期举办钓鱼比赛，游客可以参加并展示自己的钓鱼技巧。比赛结束后，农家乐会为获胜者颁发奖品。</li><li>手工制作：游客可以参加手工制作活动，如制作稻草人、编织竹篮等，了解传统的农耕文化和手工艺术。</li><li>夜间篝火晚会：在夜晚，农家乐会为游客举办篝火晚会，游客可以围着篝火跳舞、唱歌、玩游戏等，度过一个愉快的夜晚。</li></ol><p>六、住宿设施：</p><p>田园绿洲为游客提供了多种住宿选择，包括传统的江南水乡民居和现代化的别墅。民居内设有舒适的客房、宽敞的庭院和独立的卫生间等设施；别墅则配备了豪华的客厅、卧室、厨房和泳池等设施。游客可以根据自己的需求和预算选择合适的住宿方式。</p><p>总结：</p><p>田园绿洲农家乐以其独特的自然风光、丰富的农耕文化和宁静的乡村环境吸引了大量的游客前来体验。在这里，游客可以参观农田、果园等农业景观，参加各种农事活动和娱乐活动，品尝美食，享受宁静的乡村生活。同时，田园绿洲还为游客提供了多种住宿选择和特色活动，可以满足不同游客的需求。如果您想感受江南水乡的独特魅力、领略农耕文化的深厚底蕴，不妨选择田园绿洲作为您的旅行目的地之一。</p>', 0, 0, 1, '2024-05-29 17:45:36', 1);
INSERT INTO `introduction` VALUES (5, '浙江省杭州市西湖区【西山人家】', 'http://localhost:9090/files/1716976486224-山西人家.jpg', '<p>农家乐介绍：</p><p>这家农家乐位于浙江省杭州市西湖区，是一个集农业观光、休闲度假、餐饮娱乐为一体的综合性农家乐。这里有着得天独厚的自然环境、丰富的人文景观和深厚的农耕文化底蕴，为游客提供了一个远离喧嚣、回归自然的休闲胜地。</p><p>该农家乐的建筑风格以传统的江南水乡民居为主，白墙黛瓦，古色古香。院内绿树成荫，各种花卉争奇斗艳，让人感受到一种宁静和舒适。农家乐的特色在于其独特的农业观光项目，游客可以在这里参观农田、果园、养殖场等，亲身体验农耕文化，了解各种农作物的种植技术和养殖方法。此外，还可以参加各种农事活动，如采摘水果、蔬菜，钓鱼等，感受劳动的乐趣。</p><p>除了农业观光项目，该农家乐还为游客提供了多种休闲娱乐设施。游客可以在宽敞的院子里散步、观景，或者在舒适的休息区品茶聊天。此外，还可以参加各种娱乐活动，如打牌、唱歌、跳舞等，享受轻松愉快的假期。</p><p><img src=\"http://101.35.218.50:9091/files/1702130724833-%E8%A5%BF%E5%B1%B1%E4%BA%BA%E5%AE%B6.jpg\"/></p><p>该农家乐的美食也是一大亮点。这里的食材大部分来自于自家的农田和果园，新鲜、绿色、无污染。游客可以品尝到各种地道的浙江美食，如西湖醋鱼、龙井虾仁等。此外，还可以参加各种美食制作活动，如DIY披萨、烤面包等，感受制作美食的乐趣。</p><p>联系方式：<br/>电话：0571-12345678<br/>邮箱：<a href=\"mailto:info@xiashanfarm.com\" target=\"_blank\">info@xiashanfarm.com</a></p><p>交通指南：<br/>从杭州市区出发，可以选择乘坐公交车或者出租车前往该农家乐。具体路线如下：</p><ol><li>公交车：乘坐K82路公交车，在“西湖景区”站下车，然后步行约10分钟即可到达该农家乐。</li><li>出租车：从杭州市中心出发，乘坐出租车前往该农家乐，大约需要40-60分钟的车程。</li></ol><p>总结：<br/>这家位于浙江省杭州市西湖区的农家乐是一个集农业观光、休闲度假、餐饮娱乐为一体的综合性农家乐。这里有着优美的自然风光、丰富的农耕文化和各种休闲娱乐设施，为游客提供了一个远离城市喧嚣、回归自然的体验。游客可以在这里参观农田、果园等农业景观，参加各种农事活动和娱乐活动，品尝美食。如果您想感受江南水乡的独特魅力、领略农耕文化的深厚底蕴，不妨选择这家农家乐作为您的旅行目的地之一。</p>', 1, 1, 1, '2024-05-29 17:54:52', 1);
INSERT INTO `introduction` VALUES (6, '中国四川省都江堰市【青城山农家乐】', 'http://localhost:9090/files/1717052154796-青城山农家乐.jpg', '<p>详细介绍：</p><p>青城山农家乐位于中国四川省都江堰市的青城山景区内，是集休闲、观光、度假于一体的农家乐。这里环境幽静，空气清新，以优美的自然风光和丰富的农耕文化为特色，吸引了大量的游客前来体验。</p><p>青城山农家乐的建筑风格以传统的川西民居为主，房屋以木质结构为主，配有仿古石墙和砖瓦屋顶。农家乐周围环绕着绿树和鲜花，庭院宽敞，适合游客散步和休息。在这里，游客可以亲自参与农耕活动，体验收获的喜悦，还可以品尝到地道的四川美食，如麻婆豆腐、回锅肉等。</p><p>除了农业观光项目，青城山农家乐还为游客提供了多种娱乐活动，如钓鱼、采摘、烧烤、篝火晚会等。在晚上，游客可以在农家乐的露天广场上参加篝火晚会，欣赏当地民俗表演，品尝四川特色小吃，感受乡村生活的乐趣。</p><p><img src=\"http://101.35.218.50:9091/files/1702131744947-%E9%9D%92%E5%9F%8E%E5%B1%B1%E5%86%9C%E5%AE%B6%E4%B9%90.jpg\"/></p><p>三、联系方式：</p><p>电话：+86-28-87263766</p><p>邮箱：<a href=\"mailto:qingchengshanajia@example.com\" target=\"_blank\">qingchengshanajia@example.com</a></p><p>四、交通指南：</p><ol><li>飞机：从全国各地可以乘坐飞机到达成都双流国际机场，然后乘坐机场大巴或者出租车到达都江堰市，再换乘公交车到达青城山景区内的农家乐。</li><li>高铁/火车：从全国各地可以乘坐高铁或火车到达成都东站或成都南站，然后换乘地铁到达成都茶店子汽车站，再乘坐前往都江堰市的班车，到达都江堰市后换乘公交车到达青城山景区内的农家乐。</li><li>自驾：从成都市区出发，沿着G317国道向都江堰市方向行驶，经过灌县古城后进入青城山景区，根据指示牌到达农家乐。景区内道路畅通，适合自驾游。</li></ol><p>总结：</p><p>青城山农家乐以其优美的自然风光和丰富的农耕文化吸引了大量的游客。在这里，游客可以参观农田、果园等农业景观，参加各种农事活动和娱乐活动，品尝美食，享受宁静的乡村生活。同时，青城山农家乐还为游客提供了多种住宿选择，包括传统的川西民居和现代化的别墅，可以满足不同游客的需求。如果您想感受川西乡村的独特魅力、领略农耕文化的深厚底蕴，不妨选择青城山农家乐作为您的旅行目的地之一。</p>', 1, 1, 12, '2024-05-30 14:56:04', 2);
INSERT INTO `introduction` VALUES (7, '湖南省张家界市【山水人家】', 'http://localhost:9090/files/1717052181838-山水人家.jpg', '<p>详细介绍：</p><p>山水人家位于中国的湖南省张家界市，这里风景秀丽，被誉为中国最美的乡村之一。山水人家农家乐凭借其独特的自然风光、丰富的农耕文化和舒适的休闲环境，成为了国内知名的农家乐之一。</p><p>山水人家的建筑风格以传统的湘西民居为主，古色古香，充满了浓郁的乡土气息。农家乐的庭院宽敞，布满了各种花草树木，春夏秋冬四季皆有不同的景致。游客在这里可以感受到大自然的韵味和农耕的乐趣，同时可以品尝到地道的农家菜，享受到宁静的乡村生活。</p><p>山水人家提供丰富的农业观光项目，游客可以参观农田、果园、茶园、养殖场等，了解各种农作物的种植技术和养殖方法，还可以亲自参与农耕活动，体验收获的喜悦。除此之外，山水人家还为游客提供各种娱乐活动，如钓鱼、采摘、烧烤、篝火晚会等，让游客在享受大自然的同时，也能感受到乡村生活的乐趣。</p><p><img src=\"http://101.35.218.50:9091/files/1702131312813-%E5%B1%B1%E6%B0%B4%E4%BA%BA%E5%AE%B6.jpg\"/></p><p>三、联系方式：</p><p>电话：0744-1234567</p><p>邮箱：<a href=\"mailto:shanshuirenjia@example.com\" target=\"_blank\">shanshuirenjia@example.com</a></p><p>四、交通指南：</p><ol><li>飞机：从全国各地可以乘坐飞机到达张家界荷花国际机场，然后乘坐出租车或者公交车到达山水人家，大约需要1小时的车程。</li><li>高铁/火车：从全国各地可以乘坐高铁或火车到达张家界火车站，然后乘坐出租车或者公交车到达山水人家，大约需要1.5小时的车程。</li><li>自驾：从张家界市区出发，沿着S228省道向南行驶，经过大约40分钟的车程即可到达山水人家。沿途风景秀丽，路况良好，适合自驾游。</li></ol><p>总结：</p><p>山水人家农家乐以其独特的自然风光、丰富的农耕文化和舒适的休闲环境吸引了众多的游客。在这里，游客可以参观农田、果园等农业景观，参加各种农事活动和娱乐活动，品尝美食，享受宁静的乡村生活。同时，山水人家还为游客提供了多种住宿选择，包括传统的湘西民居和现代化的别墅，可以满足不同游客的需求。如果您想感受湘西乡村的独特魅力、领略农耕文化的深厚底蕴，不妨选择山水人家作为您的旅行目的地之一。</p>', 4, 1, 106, '2024-05-30 14:56:27', 2);

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标题',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建时间',
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '公告信息表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (1, '今天系统正式上线，开始内测', '今天系统正式上线，开始内测', '2023-09-05', 'admin');
INSERT INTO `notice` VALUES (2, '所有功能都已完成，可以正常使用', '所有功能都已完成，可以正常使用', '2023-09-05', 'admin');
INSERT INTO `notice` VALUES (3, '今天天气很不错，可以出去一起玩了', '今天天气很不错，可以出去一起玩了', '2023-09-05', 'admin');

-- ----------------------------
-- Table structure for trainorders
-- ----------------------------
DROP TABLE IF EXISTS `trainorders`;
CREATE TABLE `trainorders`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '车次名称',
  `user_id` int(10) NULL DEFAULT NULL COMMENT '用户ID',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '下单时间',
  `fly_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发时间',
  `start_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发站',
  `end_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达站',
  `time_slot` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '车次时长',
  `num` int(10) NULL DEFAULT NULL COMMENT '车票数量',
  `price` double(10, 2) NULL DEFAULT NULL COMMENT '车票价格',
  `order_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '订单编号',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '订单状态',
  `ticket_id` int(10) NULL DEFAULT NULL COMMENT '车票ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '火车票订单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of trainorders
-- ----------------------------
INSERT INTO `trainorders` VALUES (13, 'G3205', 1, '2024-05-29 16:06:16', '2024-05-30 13:30:00', '上海虹桥站', '北京南站', '2小时30分钟', 2, 200.00, '20240529160616', '已退票', 14);
INSERT INTO `trainorders` VALUES (14, 'G3001', 1, '2024-05-29 16:12:05', '2024-05-30 13:00:00', '上海虹桥站', '合肥站', '2小时', 1, 190.00, '20240529161205', '已购买', 12);
INSERT INTO `trainorders` VALUES (15, 'G3425', 1, '2024-05-31 16:40:47', '2024-06-01 08:00:00', '重庆南站', '上海南站', '2小时15分钟', 1, 400.00, '20240531164047', '已购买', 8);

-- ----------------------------
-- Table structure for trainticket
-- ----------------------------
DROP TABLE IF EXISTS `trainticket`;
CREATE TABLE `trainticket`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '车次名称',
  `start_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发时间',
  `end_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达时间',
  `start_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发站',
  `end_airport` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达站',
  `price` double(10, 2) NULL DEFAULT NULL COMMENT '车票费用',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '火车时长',
  `num` int(10) NULL DEFAULT 0 COMMENT '剩余票数',
  `start_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '出发城市',
  `end_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '到达城市',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '火车票信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of trainticket
-- ----------------------------
INSERT INTO `trainticket` VALUES (8, 'G3425', '08:00:00', '10:20:00', '重庆南站', '上海南站', 400.00, '2小时15分钟', 99, '重庆', '上海');
INSERT INTO `trainticket` VALUES (9, 'G5478', '10:00:00', '13:00:00', '烟台南站', '上海火车站', 200.00, '3小时', 100, '烟台', '上海');
INSERT INTO `trainticket` VALUES (10, 'G5213', '13:00:00', '15:00:00', '大连南站', '上海虹桥站', 200.00, '2小时', 100, '大连', '上海');
INSERT INTO `trainticket` VALUES (11, 'G3812', '10:30:00', '13:00:00', '青岛南站', '上海南站', 300.00, '2小时30分钟', 100, '青岛', '上海');
INSERT INTO `trainticket` VALUES (12, 'G3001', '13:00:00', '15:00:00', '上海虹桥站', '合肥站', 190.00, '2小时', 100, '上海', '合肥');
INSERT INTO `trainticket` VALUES (13, 'G2805', '16:00:00', '18:30:00', '上海虹桥站', '合肥南站', 200.00, '2小时', 99, '上海', '合肥');
INSERT INTO `trainticket` VALUES (14, 'G3205', '13:30:00', '16:00:00', '上海虹桥站', '北京南站', 200.00, '2小时30分钟', 100, '上海', '北京');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '头像',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '姓名',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '电话',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  `account` double(10, 2) NULL DEFAULT 0.00 COMMENT '余额',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'zhangsan', '123456', 'http://localhost:9090/files/1714037156217-柴犬.jpeg', '张三', 'USER', '18800009999', 'zhangsan@xm.com', 110.00);
INSERT INTO `user` VALUES (2, 'lisi', '123456', 'http://localhost:9090/files/1714037638648-柯基.jpeg', '李四', 'USER', '18887777666', 'lisi@xm.com', 0.00);
INSERT INTO `user` VALUES (6, 'wangwu', '123456', 'http://localhost:9090/files/1715069479370-柯基.jpeg', '王五', 'USER', '18877776666', 'wangwu@xm.com', 700.00);

SET FOREIGN_KEY_CHECKS = 1;
