import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

// 解决导航栏或者底部导航tabBar中的vue-router在3.0版本以上频繁点击菜单报错的问题。
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push (location) {
  return originalPush.call(this, location).catch(err => err)
}

const routes = [
  {
    path: '/',
    name: 'Manager',
    component: () => import('../views/Manager.vue'),
    redirect: '/home',  // 重定向到主页
    children: [
      { path: '403', name: 'NoAuth', meta: { name: '无权限' }, component: () => import('../views/manager/403') },
      { path: 'home', name: 'Home', meta: { name: '系统首页' }, component: () => import('../views/manager/Home') },
      { path: 'admin', name: 'Admin', meta: { name: '管理员信息' }, component: () => import('../views/manager/Admin') },
      { path: 'adminPerson', name: 'AdminPerson', meta: { name: '个人信息' }, component: () => import('../views/manager/AdminPerson') },
      { path: 'password', name: 'Password', meta: { name: '修改密码' }, component: () => import('../views/manager/Password') },
      { path: 'notice', name: 'Notice', meta: { name: '公告信息' }, component: () => import('../views/manager/Notice') },
      { path: 'user', name: 'User', meta: { name: '用户信息' }, component: () => import('../views/manager/User') },
      { path: 'airticket', name: 'Airticket', meta: { name: '飞机票信息' }, component: () => import('../views/manager/Airticket') },
      { path: 'trainticket', name: 'Trainticket', meta: { name: '火车票信息' }, component: () => import('../views/manager/Trainticket') },
      { path: 'busticket', name: 'Busticket', meta: { name: '汽车票信息' }, component: () => import('../views/manager/Busticket') },
      { path: 'airorders', name: 'Airorders', meta: { name: '飞机票订单' }, component: () => import('../views/manager/Airorders') },
      { path: 'trainorders', name: 'Trainorders', meta: { name: '火车票订单' }, component: () => import('../views/manager/Trainorders') },
      { path: 'busorders', name: 'Busorders', meta: { name: '汽车票订单' }, component: () => import('../views/manager/Busorders') },
      { path: 'introduction', name: 'Introduction', meta: { name: '出行攻略' }, component: () => import('../views/manager/Introduction') },
    ]
  },
  {
    path: '/front',
    name: 'Front',
    component: () => import('../views/Front.vue'),
    children: [
      { path: 'home', name: 'Home', meta: { name: '系统首页' }, component: () => import('../views/front/Home') },
      { path: 'person', name: 'Person', meta: { name: '个人信息' }, component: () => import('../views/front/Person') },
      { path: 'airTicket', name: 'AirTicket', meta: { name: '机票信息' }, component: () => import('../views/front/AirTicket') },
      { path: 'trainTicket', name: 'TrainTicket', meta: { name: '火车票信息' }, component: () => import('../views/front/TrainTicket') },
      { path: 'busTicket', name: 'BusTicket', meta: { name: '汽车票订单' }, component: () => import('../views/front/BusTicket') },
      { path: 'airorders', name: 'Airorders', meta: { name: '飞机票订单' }, component: () => import('../views/front/Airorders') },
      { path: 'trainorders', name: 'Trainorders', meta: { name: '火车票订单' }, component: () => import('../views/front/Trainorders') },
      { path: 'busorders', name: 'Busorders', meta: { name: '汽车票订单' }, component: () => import('../views/front/Busorders') },
      { path: 'myIntroduction', name: 'MyIntroduction', meta: { name: '我的攻略' }, component: () => import('../views/front/MyIntroduction') },
      { path: 'introduction', name: 'Introduction', meta: { name: '旅游攻略' }, component: () => import('../views/front/Introduction') },
      { path: 'introDetail', name: 'IntroDetail', meta: { name: '旅游攻略' }, component: () => import('../views/front/IntroDetail') },
      { path: 'myCollect', name: 'MyCollect', meta: { name: '我的收藏' }, component: () => import('../views/front/MyCollect') },
    ]
  },
  { path: '/login', name: 'Login', meta: { name: '登录' }, component: () => import('../views/Login.vue') },
  { path: '/register', name: 'Register', meta: { name: '注册' }, component: () => import('../views/Register.vue') },
  { path: '*', name: 'NotFound', meta: { name: '无法访问' }, component: () => import('../views/404.vue') },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// 注：不需要前台的项目，可以注释掉该路由守卫
// 路由守卫
// router.beforeEach((to ,from, next) => {
//   let user = JSON.parse(localStorage.getItem("xm-user") || '{}');
//   if (to.path === '/') {
//     if (user.role) {
//       if (user.role === 'USER') {
//         next('/front/home')
//       } else {
//         next('/home')
//       }
//     } else {
//       next('/login')
//     }
//   } else {
//     next()
//   }
// })

export default router
