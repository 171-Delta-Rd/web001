<template>
  <div class="main-content">
    <div style="width: 75%; margin: 20px auto">
      <div style="font-size: 18px; font-weight: bold; color: #333333">{{introductionData.name}}</div>
      <div style="margin-top: 20px; display: flex; color: #666666; align-items: center">
        <div style="margin-right: 30px">作者：{{introductionData.userName}}</div>
        <div><i class="el-icon-view"></i> {{introductionData.views}}</div>
        <div style="margin: 0 30px"><i class="el-icon-star-off"></i> {{introductionData.collect}}</div>
        <div><i class="el-icon-chat-line-square"></i> {{introductionData.comment}}</div>
        <div style="margin-left: 30px"><el-button size="mini" type="primary" @click="collect">收藏</el-button></div>
      </div>
      <div style="margin-top: 30px" v-html="introductionData.content" class="w-e-text w-e-text-container"></div>
    </div>
    <div style="width: 60%; margin: 50px auto">
      <div style="color: #9a6d2a; font-size: 17px; font-weight: bold; margin: 20px 0">请发表您的评价</div>
      <div>
        <el-input type="textarea" v-model="content" :rows="5" placeholder="请输入您的评价"></el-input>
      </div>
      <div style="margin-top: 10px; text-align: right">
        <el-button type="primary" @click="addComment">提交</el-button>
      </div>
      <div style="color: #9a6d2a; font-size: 17px; font-weight: bold; margin: 20px 0">看看其他小伙伴对攻略的评价（{{commentData.length}}）</div>
      <div style="margin-top: 20px">
        <el-row :gutter="10" v-for="item in commentData" style="line-height: 40px; margin-bottom: 20px">
         <el-col :span="4">
           <div style="display: flex; align-items: center">
             <img :src="item.userAvatar" alt="" style="width: 40px; height: 40px; border-radius: 50%">
             <div style="margin-left: 10px">{{item.userName}}</div>
           </div>
         </el-col>
         <el-col :span="16">{{ item.content }}</el-col>
         <el-col :span="4" style="color: #666666">{{ item.time }}</el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import E from 'wangeditor'
export default {

  data() {
    return {
      user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
      introductionId: this.$route.query.id,
      introductionData: {},
      content: null,
      commentData: []
    }
  },
  mounted() {
    this.loadIntroduction()
    this.loadComment()
  },
  // methods：本页面所有的点击事件或者其他函数定义区
  methods: {
    loadIntroduction() {
      this.$request('/introduction/selectById/' + this.introductionId).then(res => {
        if (res.code === '200') {
          this.introductionData = res.data
          this.introductionData.views = this.introductionData.views + 1
          this.updateIntroduction()
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    updateIntroduction() {
      this.$request.put('/introduction/update', this.introductionData).then(res => {
        if (res.code !== '200') {
          this.$message.error(res.msg)
        }
      })
    },
    collect() {
      let data = {
        introductionId: this.introductionId,
        userId: this.user.id,
      }
      this.$request.post('/collect/add', data).then(res => {
        if (res.code === '200') {
          this.$message.success('收藏成功')
          this.introductionData.collect = this.introductionData.collect + 1
          this.updateIntroduction()
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    addComment() {
      let data = {
        userId: this.user.id,
        introductionId: this.introductionId,
        content: this.content
      }
      this.$request.post('/comment/add', data).then(res => {
        if (res.code === '200') {
          this.$message.success('评价成功')
          this.content = null
          // 更新一下该攻略的评论数
          this.introductionData.comment = this.introductionData.comment + 1
          this.updateIntroduction()
          this.loadComment()
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    loadComment() {
      this.$request.get('/comment/selectAll', {
        params: {
          introductionId: this.introductionId
        }
      }).then(res => {
        if (res.code === '200') {
          this.commentData = res.data
        } else {
          this.$message.error(res.msg)
        }
      })
    }
  }
}
</script>
<style>
.overflowShow {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis
}
p, ol {
  color: #333333;
}
</style>