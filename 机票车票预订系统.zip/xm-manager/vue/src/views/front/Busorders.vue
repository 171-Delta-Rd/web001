<template>
  <div class="main-content">
    <div style="margin: 30px auto; width: 85%">
      <el-table :data="tableData" stripe>
        <el-table-column prop="name" label="车次名称" width="150" show-overflow-tooltip fixed="left"></el-table-column>
        <el-table-column prop="userName" label="用户姓名" show-overflow-tooltip></el-table-column>
        <el-table-column prop="time" label="下单时间" width="150"></el-table-column>
        <el-table-column prop="startAirport" label="起始站"></el-table-column>
        <el-table-column prop="endAirport" label="到达站"></el-table-column>
        <el-table-column prop="flyTime" label="出发时间" width="150"></el-table-column>
        <el-table-column prop="timeSlot" label="车次时长"></el-table-column>
        <el-table-column prop="num" label="车票数量"></el-table-column>
        <el-table-column prop="price" label="车票价格"></el-table-column>
        <el-table-column prop="orderNo" label="订单编号" width="120"></el-table-column>
        <el-table-column prop="status" label="订单状态" fixed="right"></el-table-column>

        <el-table-column label="操作" width="220" align="center" fixed="right">
          <template v-slot="scope">
            <el-button plain type="primary" size="mini" :disabled="scope.row.status === '已退票'" @click="returnTicket(scope.row)">退票</el-button>
            <el-button plain type="primary" size="mini" :disabled="scope.row.status === '已退票'" @click="changeTicket(scope.row)">改签</el-button>
            <el-button plain type="danger" size="mini" @click=del(scope.row.id)>删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination" style="margin-top: 20px">
        <el-pagination
            background
            @current-change="handleCurrentChange"
            :current-page="pageNum"
            :page-sizes="[5, 10, 20]"
            :page-size="pageSize"
            layout="total, prev, pager, next"
            :total="total">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="改签信息" :visible.sync="fromVisible" width="50%" :close-on-click-modal="false" destroy-on-close>
      <el-form label-width="100px" style="padding-right: 50px">
        <el-form-item prop="begin" label="出发时间">
          <el-date-picker style="width: 100%"
                          v-model="begin"
                          type="date"
                          value-format="yyyy-MM-dd"
                          placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item prop="ticketId" label="选择车次">
          <el-select v-model="ticketId" placeholder="请选择车次" style="width: 100%">
            <el-option v-for="item in changes" :label="item.name + '~' + item.startAirport + '-' + item.endAirport + '~' + item.startTime + '-' + item.endTime" :value="item.id" :key="item.id"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="fromVisible = false">取 消</el-button>
        <el-button type="primary" @click="doChange">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>

export default {

  data() {
    return {
      user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
      tableData: [],
      pageNum: 1,   // 当前的页码
      pageSize: 10,  // 每页显示的个数
      total: 0,
      changes: [],
      fromVisible: false,
      begin: null,
      ticketId: null,
      form: {},
    }
  },
  mounted() {
    this.load(1)
  },
  // methods：本页面所有的点击事件或者其他函数定义区
  methods: {
    load(pageNum) {  // 分页查询
      if (pageNum) this.pageNum = pageNum
      this.$request.get('/busorders/selectPage', {
        params: {
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          userId: this.user.id
        }
      }).then(res => {
        this.tableData = res.data?.list
        this.total = res.data?.total
      })
    },
    del(id) {   // 单个删除
      this.$confirm('您确定删除吗？', '确认删除', {type: "warning"}).then(response => {
        this.$request.delete('/busorders/delete/' + id).then(res => {
          if (res.code === '200') {   // 表示操作成功
            this.$message.success('操作成功')
            this.load(1)
          } else {
            this.$message.error(res.msg)  // 弹出错误的信息
          }
        })
      }).catch(() => {
      })
    },
    handleCurrentChange(pageNum) {
      this.load(pageNum)
    },
    returnTicket(row) {
      this.$request.post('/busorders/returnTicket', row).then(res => {
        if (res.code === '200') {
          this.$message.success('退票成功')
          this.load(1)
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    changeTicket(row) {
      this.$request.post('/busticket/getChange', row).then(res => {
        if (res.code === '200') {
          this.changes = res.data
          this.form = JSON.parse(JSON.stringify(row))
          this.fromVisible = true
        } else {
          this.$message.error(res.msg)
        }
      })
    },
    doChange() {
      this.form.ticketId = this.ticketId
      this.form.begin = this.begin
      console.log(this.form)
      this.$request.post('/busorders/change', this.form).then(res => {
        if (res.code === '200') {
          this.$message.success('改签成功')
          this.fromVisible = false
          this.load(1)
        } else {
          this.$message.error(res.msg)
        }
      })
    }
  }
}
</script>
<style>
.overflowShow {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis
}
</style>