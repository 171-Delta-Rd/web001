package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.entity.Trainorders;
import com.example.entity.Trainticket;
import com.example.entity.User;
import com.example.exception.CustomException;
import com.example.mapper.TrainordersMapper;
import com.example.mapper.TrainticketMapper;
import com.example.mapper.UserMapper;
import com.example.utils.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

/**
 * 车票订单表业务处理
 **/
@Service
public class TrainordersService {

    @Resource
    private TrainordersMapper trainordersMapper;
    @Resource
    private TrainticketMapper trainticketMapper;
    @Resource
    private UserMapper userMapper;

    /**
     * 新增
     */
    public void add(Trainorders trainorders) throws ParseException {
        trainorders.setTime(DateUtil.now());
        trainorders.setOrderNo(DateUtil.format(new Date(), "yyyyMMddHHmmss"));

        // 1. 判断一下车票的剩余数量
        Trainticket trainticket = trainticketMapper.selectById(trainorders.getTicketId());
        if (trainticket.getNum() < trainorders.getNum()) {
            throw new CustomException("-1", "当前车票数量不足");
        }
        // 2. 判断一下用户的余额够不够这个机票的费用
        Double price = trainticket.getPrice() * trainorders.getNum();
        User user = userMapper.selectById(trainorders.getUserId());
        if (user.getAccount() < price) {
            throw new CustomException("-1", "您的余额不足，请到个人中心充值");
        }
        // 3. 判断一下当前天是否在起飞天之前
        String today = DateUtil.format(new Date(), "yyyy-MM-dd");
        if (TimeUtils.compareDate(today, trainorders.getBegin(), "yyyy-MM-dd")) {
            throw new CustomException("-1", "平台限定最早只能预订第二天的票");
        }
        trainorders.setFlyTime(trainorders.getBegin() + " " + trainticket.getStartTime());
        trainordersMapper.insert(trainorders);

        // 4. 扣除用户的余额
        user.setAccount(user.getAccount() - price);
        userMapper.updateById(user);
        // 5. 扣掉这个车票的剩余数量
        trainticket.setNum(trainticket.getNum() - trainorders.getNum());
        trainticketMapper.updateById(trainticket);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        trainordersMapper.deleteById(id);
    }

    /**
     * 批量删除
     */
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            trainordersMapper.deleteById(id);
        }
    }

    /**
     * 修改
     */
    public void updateById(Trainorders trainorders) {
        trainordersMapper.updateById(trainorders);
    }

    /**
     * 根据ID查询
     */
    public Trainorders selectById(Integer id) {
        return trainordersMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Trainorders> selectAll(Trainorders trainorders) {
        List<Trainorders> list = trainordersMapper.selectAll(trainorders);
        for (Trainorders dbOrders : list) {
            dbOrders.setTotal(dbOrders.getPrice() * dbOrders.getNum());
        }
        return list;
    }

    /**
     * 分页查询
     */
    public PageInfo<Trainorders> selectPage(Trainorders trainorders, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Trainorders> list = trainordersMapper.selectAll(trainorders);
        return PageInfo.of(list);
    }

    /**
     * 退票功能
     */
    public void returnTicket(Trainorders trainorders) throws ParseException {
        // 1. 判断当前的时间是否已经过了起飞的时间
        String now = DateUtil.now();
        String flyTime = trainorders.getFlyTime();
        if (!TimeUtils.compareDate(flyTime, now, "yyyy-MM-dd HH:mm:ss")) {
            throw new CustomException("-1", "您的车次已经出发，无法退票");
        }
        // 2. 退票
        trainorders.setStatus("已退票");
        trainordersMapper.updateById(trainorders);
        // 3. 退钱
        User user = userMapper.selectById(trainorders.getUserId());
        user.setAccount(user.getAccount() + trainorders.getNum() * trainorders.getPrice());
        userMapper.updateById(user);
        // 4. 票数返还
        Trainticket trainticket = trainticketMapper.selectById(trainorders.getTicketId());
        trainticket.setNum(trainticket.getNum() + trainorders.getNum());
        trainticketMapper.updateById(trainticket);
    }

    /**
     * 改签功能
     */
    public void change(Trainorders trainorders) throws ParseException {
        // 获取今天的时间
        String today = DateUtil.format(new Date(), "yyyy-MM-dd");
        if (TimeUtils.compareDate(today, trainorders.getBegin(), "yyyy-MM-dd")) {
            throw new CustomException("-1", "平台限定最早只能改签第二天的票");
        }
        // 计算一下是否需要补差价或者退差价
        User user = userMapper.selectById(trainorders.getUserId());
        double price = trainorders.getNum() * trainorders.getPrice();
        Integer ticketId = trainorders.getTicketId();
        Trainticket trainticket = trainticketMapper.selectById(ticketId);
        double nowPrice = trainticket.getPrice() * trainorders.getNum();
        if (price < nowPrice) {
            double gap = nowPrice - price;
            if (user.getAccount() < gap) {
                throw new CustomException("-1", "您的余额不足，请到个人中心充值");
            } else {
                // 用户补差价
                user.setAccount(user.getAccount() - gap);
                userMapper.updateById(user);
            }
        }
        if (price > nowPrice) {
            double gap = price - nowPrice;
            // 平台退差价
            user.setAccount(user.getAccount() + gap);
            userMapper.updateById(user);
        }
        // 更新一下改签后的订单信息
        trainorders.setName(trainticket.getName());
        trainorders.setFlyTime(trainorders.getBegin() + " " + trainticket.getStartTime());
        trainorders.setStartAirport(trainticket.getStartAirport());
        trainorders.setEndAirport(trainticket.getEndAirport());
        trainorders.setTimeSlot(trainticket.getTime());
        trainorders.setPrice(trainticket.getPrice());

        trainordersMapper.updateById(trainorders);
    }
}