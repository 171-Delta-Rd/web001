package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.entity.Account;
import com.example.entity.Airorders;
import com.example.entity.Airticket;
import com.example.exception.CustomException;
import com.example.mapper.AirticketMapper;
import com.example.utils.TimeUtils;
import com.example.utils.TokenUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 机票信息表业务处理
 **/
@Service
public class AirticketService {

    @Resource
    private AirticketMapper airticketMapper;

    /**
     * 新增
     */
    public void add(Airticket airticket) {
        airticketMapper.insert(airticket);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        airticketMapper.deleteById(id);
    }

    /**
     * 批量删除
     */
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            airticketMapper.deleteById(id);
        }
    }

    /**
     * 修改
     */
    public void updateById(Airticket airticket) {
        airticketMapper.updateById(airticket);
    }

    /**
     * 根据ID查询
     */
    public Airticket selectById(Integer id) {
        return airticketMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Airticket> selectAll(Airticket airticket) {
        List<Airticket> airtickets = airticketMapper.selectAll(airticket);
        for (Airticket dbAirTicket : airtickets) {
            String name = dbAirTicket.getName();
            String left = name.split(" ")[0];
            String right = name.split(" ")[1];
            dbAirTicket.setLeft(left);
            dbAirTicket.setRight(right);
        }
        return airtickets;
    }

    /**
     * 分页查询
     */
    public PageInfo<Airticket> selectPage(Airticket airticket, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Airticket> list = airticketMapper.selectAll(airticket);
        return PageInfo.of(list);
    }

    /**
     * 获取跟当前航班匹配的可改签的航班
     */
    public List<Airticket> getChange(Airorders airorders) throws ParseException {
        // 1. 判断当前的时间是否已经过了起飞的时间
        String now = DateUtil.now();
        String flyTime = airorders.getFlyTime();
        if (!TimeUtils.compareDate(flyTime, now, "yyyy-MM-dd HH:mm:ss")) {
            throw new CustomException("-1", "您的航班已经起飞，无法改签");
        }
        // 查询出待改签的航班
        Integer ticketId = airorders.getTicketId();
        Airticket airticket = airticketMapper.selectById(ticketId);
        // 查询所有的航班
        List<Airticket> airtickets = airticketMapper.selectAll(new Airticket());
        // 筛选可改签的航班
        return airtickets.stream()
                .filter(x -> x.getStartCity().equals(airticket.getStartCity())
                        && x.getEndCity().equals(airticket.getEndCity())
                        && x.getNum() >= airorders.getNum()
                        && !x.getId().equals(ticketId))
                .collect(Collectors.toList());
    }
}