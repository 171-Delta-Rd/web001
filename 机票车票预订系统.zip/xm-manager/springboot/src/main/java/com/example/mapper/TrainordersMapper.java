package com.example.mapper;

import com.example.entity.Trainorders;

import java.util.List;

/**
 * 操作trainorders相关数据接口
*/
public interface TrainordersMapper {

    /**
      * 新增
    */
    int insert(Trainorders trainorders);

    /**
      * 删除
    */
    int deleteById(Integer id);

    /**
      * 修改
    */
    int updateById(Trainorders trainorders);

    /**
      * 根据ID查询
    */
    Trainorders selectById(Integer id);

    /**
      * 查询所有
    */
    List<Trainorders> selectAll(Trainorders trainorders);

}