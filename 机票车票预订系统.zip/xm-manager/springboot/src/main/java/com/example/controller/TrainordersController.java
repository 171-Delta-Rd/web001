package com.example.controller;

import com.example.common.Result;
import com.example.entity.Trainorders;
import com.example.service.TrainordersService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.List;

/**
 * 车票订单表前端操作接口
 **/
@RestController
@RequestMapping("/trainorders")
public class TrainordersController {

    @Resource
    private TrainordersService trainordersService;

    /**
     * 新增
     */
    @PostMapping("/add")
    public Result add(@RequestBody Trainorders trainorders) throws ParseException {
        trainordersService.add(trainorders);
        return Result.success();
    }

    @PostMapping("/returnTicket")
    public Result returnTicket(@RequestBody Trainorders trainorders) throws ParseException {
        trainordersService.returnTicket(trainorders);
        return Result.success();
    }

    @PostMapping("/change")
    public Result change(@RequestBody Trainorders trainorders) throws ParseException {
        trainordersService.change(trainorders);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        trainordersService.deleteById(id);
        return Result.success();
    }

    /**
     * 批量删除
     */
    @DeleteMapping("/delete/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        trainordersService.deleteBatch(ids);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Trainorders trainorders) {
        trainordersService.updateById(trainorders);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Trainorders trainorders = trainordersService.selectById(id);
        return Result.success(trainorders);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(Trainorders trainorders ) {
        List<Trainorders> list = trainordersService.selectAll(trainorders);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(Trainorders trainorders,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Trainorders> page = trainordersService.selectPage(trainorders, pageNum, pageSize);
        return Result.success(page);
    }

}