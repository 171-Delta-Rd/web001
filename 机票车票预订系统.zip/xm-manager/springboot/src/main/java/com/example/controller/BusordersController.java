package com.example.controller;

import com.example.common.Result;
import com.example.entity.Busorders;
import com.example.service.BusordersService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.List;

/**
 * 汽车票订单表前端操作接口
 **/
@RestController
@RequestMapping("/busorders")
public class BusordersController {

    @Resource
    private BusordersService busordersService;

    /**
     * 新增
     */
    @PostMapping("/add")
    public Result add(@RequestBody Busorders busorders) throws ParseException {
        busordersService.add(busorders);
        return Result.success();
    }

    @PostMapping("/returnTicket")
    public Result returnTicket(@RequestBody Busorders busorders) throws ParseException {
        busordersService.returnTicket(busorders);
        return Result.success();
    }

    @PostMapping("/change")
    public Result change(@RequestBody Busorders busorders) throws ParseException {
        busordersService.change(busorders);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        busordersService.deleteById(id);
        return Result.success();
    }

    /**
     * 批量删除
     */
    @DeleteMapping("/delete/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        busordersService.deleteBatch(ids);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Busorders busorders) {
        busordersService.updateById(busorders);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Busorders busorders = busordersService.selectById(id);
        return Result.success(busorders);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(Busorders busorders ) {
        List<Busorders> list = busordersService.selectAll(busorders);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(Busorders busorders,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Busorders> page = busordersService.selectPage(busorders, pageNum, pageSize);
        return Result.success(page);
    }

}