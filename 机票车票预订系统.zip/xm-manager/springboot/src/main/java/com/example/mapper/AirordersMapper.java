package com.example.mapper;

import com.example.entity.Airorders;

import java.util.List;

/**
 * 操作airorders相关数据接口
*/
public interface AirordersMapper {

    /**
      * 新增
    */
    int insert(Airorders airorders);

    /**
      * 删除
    */
    int deleteById(Integer id);

    /**
      * 修改
    */
    int updateById(Airorders airorders);

    /**
      * 根据ID查询
    */
    Airorders selectById(Integer id);

    /**
      * 查询所有
    */
    List<Airorders> selectAll(Airorders airorders);

}