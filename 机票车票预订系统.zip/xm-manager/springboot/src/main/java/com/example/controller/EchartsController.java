package com.example.controller;

import cn.hutool.core.util.ObjectUtil;
import com.example.common.Result;
import com.example.entity.*;
import com.example.service.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/echarts")
public class EchartsController {

    @Resource
    private AirticketService airticketService;
    @Resource
    private AirordersService airordersService;
    @Resource
    private TrainticketService trainticketService;
    @Resource
    private TrainordersService trainordersService;
    @Resource
    private BusticketService busticketService;
    @Resource
    private BusordersService busordersService;

    @GetMapping("/pie")
    public Result pie() {
        List<Map<String, Object>> resultList = new ArrayList<>();
        // 查询出所有的航班
        List<Airticket> airtickets = airticketService.selectAll(new Airticket());
        // 查询出所有的航班的订单
        List<Airorders> airorders = airordersService.selectAll(new Airorders());
        // 遍历所有的航班
        for (Airticket airticket : airtickets) {
            Map<String, Object> map = new HashMap<>();
            String name = airticket.getName().split(" ")[0];
            // 筛选出当前的航班的所有订单并且计算总额
            Double total = airorders.stream().filter(x -> ObjectUtil.isNotEmpty(x.getTicketId()) && x.getTicketId().equals(airticket.getId()))
                    .map(Airorders::getTotal).reduce(0.0, Double::sum);
            map.put("name", name);
            map.put("value", total);
            resultList.add(map);
        }

        return Result.success(resultList);
    }

    @GetMapping("/line")
    public Result line() {
        Map<String, Object> resultMap = new HashMap<>();
        List<String> xList = new ArrayList<>();
        List<Object> yList = new ArrayList<>();

        // 查询出所有火车车次
        List<Trainticket> traintickets = trainticketService.selectAll(new Trainticket());
        // 查询出所有的火车票订单
        List<Trainorders> trainorders = trainordersService.selectAll(new Trainorders());
        for (Trainticket dbTicket : traintickets) {
            String name = dbTicket.getName();
            Double total = trainorders.stream()
                    .filter(x -> ObjectUtil.isNotEmpty(x.getTicketId()) && x.getTicketId().equals(dbTicket.getId()))
                    .map(Trainorders::getTotal).reduce(0.0, Double::sum);
            xList.add(name);
            yList.add(total);
        }

        resultMap.put("xAxis", xList);
        resultMap.put("yAxis", yList);
        return Result.success(resultMap);
    }

    @GetMapping("/bar")
    public Result bar() {
        Map<String, Object> resultMap = new HashMap<>();
        List<String> xList = new ArrayList<>();
        List<Object> yList = new ArrayList<>();

        // 查询出所有汽车车次
        List<Busticket> bustickets = busticketService.selectAll(new Busticket());
        // 查询出所有的火车票订单
        List<Busorders> busorders = busordersService.selectAll(new Busorders());
        for (Busticket dbTicket : bustickets) {
            String name = dbTicket.getName();
            Double total = busorders.stream()
                    .filter(x -> ObjectUtil.isNotEmpty(x.getTicketId()) && x.getTicketId().equals(dbTicket.getId()))
                    .map(Busorders::getTotal).reduce(0.0, Double::sum);
            xList.add(name);
            yList.add(total);
        }

        resultMap.put("xAxis", xList);
        resultMap.put("yAxis", yList);
        return Result.success(resultMap);
    }
}
