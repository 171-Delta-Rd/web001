package com.example.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeUtils {

    /**
     * 判断两个时间的大小
     * 如果返回的是true，表示 start的时间 >= end的时间
     * 如果返回的是false,表示 start的时间 < end的时间
     */
    public static boolean compareDate(String start, String end, String format) throws ParseException {
        Date flyDate = new SimpleDateFormat(format).parse(start);
        Date nowDate = new SimpleDateFormat(format).parse(end);
        // 比较两个时间的大小
        int result = flyDate.compareTo(nowDate);
        return result >= 0;
    }

    /**
     * 计算两个时间中间的天数
     * 如果返回的是正数，表示start时间 < end时间，该正数表示两个时间之间的天数
     * 如果返回的是负数，表示start时间 > end时间
     * 如果返回的是0，表示start时间 = end时间，即为同一天
     */
    public static long getDay(String start, String end) throws ParseException {
        DateFormat dft = new SimpleDateFormat("yyyy-MM-dd");
        Date star = dft.parse(start);//开始时间
        Date endDay = dft.parse(end);//结束时间
        Long starTime = star.getTime();
        Long endTime = endDay.getTime();
        long num = endTime-starTime;//时间戳相差的毫秒数
        return num/24/60/60/1000;
    }


}
