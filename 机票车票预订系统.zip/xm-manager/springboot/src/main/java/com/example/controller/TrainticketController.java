package com.example.controller;

import com.example.common.Result;
import com.example.entity.Trainorders;
import com.example.entity.Trainticket;
import com.example.service.TrainticketService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.List;

/**
 * 火车票信息表前端操作接口
 **/
@RestController
@RequestMapping("/trainticket")
public class TrainticketController {

    @Resource
    private TrainticketService trainticketService;

    /**
     * 新增
     */
    @PostMapping("/add")
    public Result add(@RequestBody Trainticket trainticket) {
        trainticketService.add(trainticket);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        trainticketService.deleteById(id);
        return Result.success();
    }

    /**
     * 批量删除
     */
    @DeleteMapping("/delete/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        trainticketService.deleteBatch(ids);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Trainticket trainticket) {
        trainticketService.updateById(trainticket);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Trainticket trainticket = trainticketService.selectById(id);
        return Result.success(trainticket);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(Trainticket trainticket ) {
        List<Trainticket> list = trainticketService.selectAll(trainticket);
        return Result.success(list);
    }

    @PostMapping("/getChange")
    public Result getChange(@RequestBody Trainorders trainorders) throws ParseException {
        List<Trainticket> list = trainticketService.getChange(trainorders);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(Trainticket trainticket,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Trainticket> page = trainticketService.selectPage(trainticket, pageNum, pageSize);
        return Result.success(page);
    }

}